import React from 'react';

function Youtuobe() {
	return (
		<section className='content youtube'>
			<div className='inner'>
				<h1>Youtube</h1>
				<figure></figure>
			</div>
		</section>
	);
}

export default Youtuobe;
