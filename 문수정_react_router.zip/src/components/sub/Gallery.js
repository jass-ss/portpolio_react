import React from 'react';

function Gallery() {
	return (
		<section className='content gallery'>
			<div className='inner'>
				<h1>Gallery</h1>
				<figure></figure>
			</div>
		</section>
	);
}

export default Gallery;
