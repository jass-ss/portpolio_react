import React from 'react';

function Store() {
	return (
		<section className='content store'>
			<div className='inner'>
				<h1>Store</h1>
				<figure></figure>
			</div>
		</section>
	);
}

export default Store;
