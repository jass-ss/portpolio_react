import React from 'react';

function Product() {
	return (
		<section className='content product'>
			<div className='inner'>
				<h1>Product</h1>
				<figure></figure>
			</div>
		</section>
	);
}

export default Product;
