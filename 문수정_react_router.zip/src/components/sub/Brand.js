import React from 'react';

function Brand() {
	return (
		<section className='content brand'>
			<div className='inner'>
				<h1>Brand</h1>
				<figure></figure>
			</div>
		</section>
	);
}

export default Brand;
