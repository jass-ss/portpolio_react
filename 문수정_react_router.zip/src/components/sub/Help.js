import React from 'react';

function Help() {
	return (
		<section className='content help'>
			<div className='inner'>
				<h1>Help</h1>
				<figure></figure>
			</div>
		</section>
	);
}

export default Help;
